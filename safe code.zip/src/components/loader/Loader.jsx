import React from "react";
import styles from "./style.css";
const Loader = () => {
  return <div className={styles.loader}></div>;
};

export default Loader;
